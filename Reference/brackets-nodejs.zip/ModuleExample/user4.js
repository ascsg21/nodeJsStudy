/**
 * 모듈에 대해 알아보기
 * 
 * module.exports에 함수 직접 할당하기
 *
 * @date 2016-11-10
 * @author Mike
 */

// 인터페이스(함수 객체)를 그대로 할당할 수 있음
 
module.exports = function() {
	return {id:'test01', name:'소녀시대'};
};
