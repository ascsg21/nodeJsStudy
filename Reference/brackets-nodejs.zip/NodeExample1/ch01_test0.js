console.log('안녕하세요.');

console.log('반가워요.');

console.log('고마워요.');
