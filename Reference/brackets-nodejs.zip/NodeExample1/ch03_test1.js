/**
 * 3장 Test 1
 * 
 * 자바스크립트의 변수 타입
 */

var age = 20;
console.log('나이 : %d', age);

var name = '소녀시대';
console.log('이름 : %s', name);

