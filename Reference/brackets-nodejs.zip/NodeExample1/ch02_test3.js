/**
 * 2장 Test 3
 * 
 * env 객체 사용하여 환경변수의 값 알아내기
 */

console.dir(process.env);

console.log('OS 환경변수의 값 : ' + process.env[OS]);
