/**
 * 3장 Test 3
 * 
 * 자바스크립트의 함수
 * 자바와 같은 타입 기반 언어의 함수에서 타입만 제외한 형태
 * 
 */

function add(a, b) {
	return a + b;
}

var result = add(10, 10);

console.log('더하기 (10, 10) : %d', result);

